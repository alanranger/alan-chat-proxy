﻿# Workspace Overview — Chat AI Bot
_Last updated: (today’s date)_

Below are the 100 largest files in this project. Keep this open in Cursor so AI understands the repo layout.


CSVSs from website\master_questions_mapped_clean.csv — 2830.5 KB
supabase-schema-igzvwbvgvmzvvzoclufx.png — 358.2 KB
api\chat.js — 231.6 KB
CSVSs from website\products_Oct-02_02-35-27AM.csv — 221.8 KB
results\live-sweep-1760517972136.json — 209.7 KB
restore_point_chat_js.js — 197.5 KB
chat_js_restore_point.js — 197.5 KB
restore_point_chat_html.html — 152.6 KB
chat_html_restore_point.html — 152.6 KB
split-testbench-logs (1).txt — 147.3 KB
package-lock.json — 145.7 KB
CSVSs from website\07 - alanranger_product_schema_FINAL_WITH_REVIEW_RATINGS.csv — 130.8 KB
public\bulk-simple.html — 130 KB
CSVSs from website\testbench-results.csv — 111.4 KB
Working Files Downloaded\comprehensive-test-results-2025-10-06T02-23-54-637Z.csv — 110.6 KB
public\analytics.html — 110.2 KB
backup\restore-point-december-2025\chat.js — 109.5 KB
results\live-sweep-1760548951930.json — 99.8 KB
backup\chat-js-3cba224.txt — 98.8 KB
public\chat.html — 91.1 KB
backup\restore-point-december-2025\chat.html — 81.6 KB
api\chat-backup.js — 81.4 KB
backup\chat-html-3cba224.txt — 75 KB
CSVSs from website\01-Alan Ranger Blog On Photography - Tips, Offers and News-CSV.csv — 71.5 KB
CSVSs from website\06 - site urls - Sheet1.csv — 62.6 KB
api\csv-import.js — 60.3 KB
CSVSs from website\testbench-results (1).csv — 52.8 KB
CSVSs from website\03 - www-alanranger-com__5013f4b2c4aaa4752ac69b17__photographic-workshops-near-me.csv — 49.3 KB
api\ingest.js — 49.1 KB
backup\restore-point-december-2025\ingest.js — 46.2 KB
Working Files Downloaded\event_product_mappings.csv — 46 KB
CSVSs from website\event-product-mappings-2025-10-07T13-27-14-346Z.csv — 45.9 KB
event-product-mappings-2025-10-11T16-07-05-413Z.csv — 45.8 KB
event-product-mappings-2025-10-12T15-55-27-929Z.csv — 45.8 KB
CSVSs from website\event-product-mappings-2025-10-09T16-37-23-230Z.csv — 45.8 KB
chat js 27 sep.txt — 43.7 KB
chat js 28 sep.txt — 42.9 KB
Working Files Downloaded\event_product_mappings-2025-10-06T14-46-57-218Z.csv — 42.8 KB
Icons\TECH SUPPORT.png — 42.2 KB
results\comprehensive-followup-results-2025-10-06T14-00-02-786Z.csv — 40.9 KB
results\comprehensive-followup-results-2025-10-06T13-49-34-622Z.csv — 40.9 KB
results\comprehensive-followup-results-2025-10-06T13-32-23-122Z.csv — 40.9 KB
chat html 27 sep.txt — 39.6 KB
Icons\VOUCHER.png — 37.5 KB
CSVSs from website\07 - alanranger_product_schema_FINAL_WITH_REVIEW_RATINGS.xlsx — 36 KB
Icons\TIPS.png — 35.8 KB
backup of chat js 826 lines  sep.txt — 35.6 KB
CSVSs from website\02 - www-alanranger-com__5013f4b2c4aaa4752ac69b17__beginners-photography-lessons.csv — 35.2 KB
Icons\RPS Mentoring Course.png — 35.2 KB
public\chat.html.bak — 35.1 KB
chat html 28 sep.txt — 35.1 KB
backup of chat html  764 lines sep.txt — 33.8 KB
api\chat-improvement.js — 32.9 KB
Working Files Downloaded\enhanced-chat-test-results-2025-10-06T03-27-00-145Z.csv — 32.3 KB
Icons\photography workshops.png — 31.9 KB
public\testbench-split.html — 31.3 KB
chat copy.html — 30.5 KB
Icons\BLOG.png — 30.5 KB
api\tools.js — 29.4 KB
public\xxx bulk.html — 29.1 KB
CSVSs from website\time-field-differences.csv — 27.4 KB
Icons\-LIGHTROOM COURSE BLACK.png — 27.3 KB
api\analytics.js — 26.9 KB
Working Files Downloaded\results-ep-2025-10-06T17-17-07.csv — 26.7 KB
public\testbench-pro.html — 26.1 KB
20-questions-validation-results.json — 25.8 KB
results\live-sweep-issues-1760527366449.csv — 25.2 KB
Architecture and Handover\SYSTEM_ARCHITECTURE.md — 24.7 KB
public\testbench.html — 24.1 KB
public\interactive-testing.html — 23.2 KB
Alan Ranger Photography Chat Bot.docx — 22.1 KB
lib\htmlExtractor.js — 21.5 KB
expanded-clarification-system-results.json — 19.8 KB
backup\restore-point-december-2025\htmlExtractor.js — 19.5 KB
Working Files Downloaded\Supabase Snippet Event product sanity — valid records.xlsx — 19.4 KB
chatbot-test-results-2025-10-14 (3).json — 18.7 KB
public\chat white.png — 18.4 KB
Icons\Photography-courses (2).png — 18.2 KB
public\old-bulk.html — 17.9 KB
split-testbench-logs.txt — 17.6 KB
CSVSs from website\photography_questions_cleaned_ALL.csv — 17.6 KB
public\testbench-chat.html — 17.3 KB
backup\restore-point-december-2025\SYSTEM_ARCHITECTURE.md — 16.9 KB
chatbot-test-results-2025-10-14 (2).json — 16.2 KB
results\live-sweep-issues-1760549663414.csv — 15.1 KB
FINAL_COMPREHENSIVE_FIX.sql — 14.7 KB
end-to-end-test.html — 14.4 KB
public\old chat.html — 13.9 KB
Icons\alan ranger photography academy logo.png — 13.8 KB
Working Files Downloaded\results-ep-events-detailed-2025-10-06T17-23-38.csv — 13.7 KB
SCALABLE_MAPPING_SYSTEM.sql — 13.6 KB
public\admin.html — 13.6 KB
CSVSs from website\test quesitons.csv — 13.2 KB
CSVSs from website\05 - Photo Workshops UK _ Landscape Photography Workshops-CSV.csv — 13.1 KB
public\embed.js — 13 KB
complete-followup-handling-results.json — 12.5 KB
backup\restore-point-december-2025\MIGRATION_GUIDE.md — 11.2 KB
ENHANCED_DATABASE_SCHEMA.sql — 10.8 KB
testbench-local.html — 10.7 KB
CSVSs from website\questions_356_intent3.csv — 10.7 KB

## Folder tree (depth 4)

.cursor\
.cursor\commands\
.cursor\rules\
.vscode\
alan-chat-proxy-main\
alan-chat-proxy-main\.cursor\
api\
Architecture and Handover\
backup\
backup\restore-point-december-2025\
CSVSs from website\
Icons\
lib\
public\
results\
scripts\
Working Files Downloaded\
